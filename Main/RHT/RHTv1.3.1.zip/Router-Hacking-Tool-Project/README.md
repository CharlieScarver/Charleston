Router-Hacking-Tool: RHT
===========================
Created by [**LAG**](https://github.com/LAGroup)

Current stable version: **1.3.1**

------------------------------

Version history:

  -> 1.0.0
  
      - basic functionality
      
      - WPA2 logic: handshake capture and dictionary usage
  
  -> 1.1.0
  
      - new, cleaner WPA2 logic
  
      
  -> 1.2.0
  
      - WEP logic: fake authentication, deauthentication and traffic acceleration
  
      - new subprocess handling logic using spawn, timeout, TERM signal


  -> 1.3.0
  
      - Reaver logic: wash and reaver
  
      - Big update on main program logic
  
      - Router selection menu has more detailed information
  
      - Instruction are added everywhere

------------------------------

Who are the [LAG](https://github.com/LAGroup):
  Alexander Apostolov aka [**CharlieScarver**](https://github.com/CharlieScarver)   &   Luboslav Ivanov aka [**killer18ys**](https://github.com/killer18ys)


LAG First Commit: **17:32 23/02/2014**
